let tekst = prompt("wprowadz tekst");

function odwroctekst() {
    return tekst.split("").reverse();
}

alert(tekst);